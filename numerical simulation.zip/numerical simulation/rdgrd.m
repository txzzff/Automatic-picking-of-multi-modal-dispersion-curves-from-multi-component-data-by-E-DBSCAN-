function [xmin,xmax,ymin,ymax,back]=rdgrd(filename)
fa=filename;
fid=fopen([fa],'rb');
cdum=fread(fid,4,'uint8=>char')';
fscanf(fid,'\n');
nx=fscanf(fid,'%d',1);
fp=fseek(fid,1,0);
ny=fscanf(fid,'%d',1);
fscanf(fid,'\n');
xmin=fscanf(fid,'%f',1);
fseek(fid,4,1);
xmax=fscanf(fid,'%f',1);
 fscanf(fid,'\n');
ymin=fscanf(fid,'%f',1);
  fseek(fid,4,1);
ymax=fscanf(fid,'%f',1);
  fscanf(fid,'\n');
zmin=fscanf(fid,'%f',1);
  fseek(fid,4,1);
zmax=fscanf(fid,'%f',1);
  fscanf(fid,'\n');
  for i=1:ny
      for m=1:nx
      data(i,m)=fscanf(fid,'%f',1);
      fseek(fid,4,1);
      end
      fscanf(fid,'\n');
  end
fid=fclose('all');
for i=1:ny
    back(i,:)=data(i,:);
end
%imagesc([xmin,xmax],[ymin,ymax],back);
%set(gca,'Ydir','normal');
%xlabel('Frequency (Hz)');
%ylabel('Phase velocity (m/s)');

