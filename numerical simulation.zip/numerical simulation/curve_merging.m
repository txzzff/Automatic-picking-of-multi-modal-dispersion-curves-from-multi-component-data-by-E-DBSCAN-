clc;
clear;
close all;
%% read data
% x component
epsilon_x=3;      
MinPts_x=10;       
% z component
epsilon_z=4;      
MinPts_z=12;      
f_min=8;
f_max=80;
v_min=150;
v_max=500;
parameter=importdata('modela.txt');
vs=parameter(1,:);   
vp=parameter(2,:); 
den=parameter(3,:);   
h=parameter(4,1:length(parameter(1,:))-1);   
fr=[f_min:f_max]; 
[xmin,xmax,ymin,ymax,Z]=rdgrd('shotza.grd');
[xmin,xmax,ymin,ymax,X]=rdgrd('shotxa.grd');
set(0, 'DefaultAxesFontSize', 20);
set(0, 'DefaultTextFontSize', 22);
set(0, 'DefaultAxesFontName', 'Times New Roman');
set(0, 'DefaultTextFontName', 'Times New Roman');
X=X(v_min-ymin+1:v_max-ymin+1,f_min-xmin+1:f_max-xmin+1);
Z=Z(v_min-ymin+1:v_max-ymin+1,f_min-xmin+1:f_max-xmin+1);
S=X+Z;
%% x component
datax=imresize(X,1);   
[h,w]=size(datax);
ave_x=mean(X(:));
coordinatex=[];
for i=1:1:h
    for j=1:1:w
        if  datax(i,j)>1.25*ave_x
            coordinatex=[coordinatex;j+f_min,i+v_min,datax(i,j);];
        end
    end
end
coordinatex(all(coordinatex==0,2),:)=[]; 
coordinate_1=coordinatex(:,1:2);
IDX_x=DBSCAN(coordinate_1,3,10);  
figure(1)
PlotClusterinResultEnhanced3(coordinate_1, IDX_x, f_min, f_max, v_min, v_max);      
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
title(['X DBSCAN Clustering result(\epsilon = ' num2str(epsilon_x) ', MinPts = ' num2str(MinPts_x) ')']);
for i=1:1:length(IDX_x)     
    for j=1:1:max(IDX_x)
        if IDX_x(i)==j
            IDX_1{j}(i)=i;
        end
    end
end
for i=1:1:max(IDX_x)
    IDX_1{1,i}(IDX_1{1,i}==0)=[]; 
end
DBSCAN_length=zeros(1,max(IDX_x));      
for i=1:1:max(IDX_x)
    DBSCAN_length(i)=length(IDX_1{1,i});
end
DBSCAN_lct=zeros(1,max(IDX_x));
Threshold_2x=0.05;
for i=1:1:length(DBSCAN_length)    
    if DBSCAN_length(i)>=Threshold_2x*mean(DBSCAN_length(:))
        DBSCAN_lct(i)=(i);
    end
    DBSCAN_lct(DBSCAN_lct==0)=[];
end
for i=1:1:max(IDX_x)
    IDX_1{1,i}=[IDX_1{1,i},zeros(1,max(DBSCAN_length)-length(IDX_1{1,i}))];
end
ex_location=[];    
for i=1:1:length(DBSCAN_lct)
    ex_location=[ex_location;IDX_1{1,DBSCAN_lct(i)}];   
end

for i=1:1:size(ex_location,1)
    e=ex_location(i,:);
    e=e(e~=0);
    x1x=coordinatex(e,1);y1x=coordinatex(e,2);z1x=coordinatex(e,3);
    data_shunxux=sortrows([x1x,y1x,z1x],1);     
    x=data_shunxux(:,1);y=data_shunxux(:,2);z=data_shunxux(:,3);
    unique_x=unique(x);       
    for j=1:length(unique_x)
        idx=(x==unique_x(j));      
        [max_z(j),idz(j)]=max(z(idx));    
        if j>=2&&j<=length(unique_x)
            idz(j)=length(x(x<=unique_x(j-1)))+idz(j);    
        end
    end
    varName=sprintf('rowx_%d', i);     
    eval([varName '=data_shunxux(idz(1:length(unique_x)),1:2)']);   
end
POL=0;      
for i=1:1:size(ex_location,1)
    varName_1=sprintf('rowx_%d', i);     
    value=eval(varName_1);
    if max(value(:,1))-min(value(:,1))>=12&&length(value(:,1))>=10     
        suo_1=[];    
        suo_2=[];
        for k=1:1:length(value(:,2))
            if value(k,2)>max(vs)    
                suo_1(k)=k; 
            end
        end
        suo_1(suo_1==0)=[];
        value(suo_1,:)=[];      
        for m=1:1:length(value(:,2))     
            if value(m,1)>f_max||value(m,1)<f_min
                suo_2(m)=m;
            end
        end
        suo_2(suo_2==0)=[];
        value(suo_2,:)=[];  
        if ~isempty(value)
            POL=POL+1;     
            varName_n=sprintf('rowx1_%d', POL);     
            eval([varName_n '=value(:,1:2)']);     
        end
    end
end
%% z component
dataz=imresize(Z,1);     
[h,w]=size(dataz);
ave_z=mean(Z(:));
coordinatez=[];
for i=1:1:h
    for j=1:1:w
        if  dataz(i,j)>0
            coordinatez=[coordinatez;j+f_min,i+v_min,dataz(i,j);];
        end
    end
end
coordinatez(all(coordinatez==0,2),:)=[];    
coordinate_2=coordinatez(:,1:2);     
IDX_z=EDBSCAN(coordinatez,2,0.5);
figure(2)
PlotClusterinResultEnhanced3(coordinate_2, IDX_z, f_min, f_max, v_min, v_max);         

for i=1:1:length(IDX_z)    
    for j=1:1:max(IDX_z)
        if IDX_z(i)==j
            IDX_2{j}(i)=i;
        end
    end
end
for i=1:1:max(IDX_z)
    IDX_2{1,i}(IDX_2{1,i}==0)=[];
end
DBSCAN_length=zeros(1,max(IDX_z));      
for i=1:1:max(IDX_z)
    DBSCAN_length(i)=length(IDX_2{1,i});
end
DBSCAN_lct=zeros(1,max(IDX_z));
Threshold_2=0.05;
for i=1:1:length(DBSCAN_length)   
    if DBSCAN_length(i)>=Threshold_2*mean(DBSCAN_length(:))
        DBSCAN_lct(i)=(i);
    end
    DBSCAN_lct(DBSCAN_lct==0)=[];
end

for i=1:1:max(IDX_z)
    IDX_2{1,i}=[IDX_2{1,i},zeros(1,max(DBSCAN_length)-length(IDX_2{1,i}))];
end
e_location=[];    
for i=1:1:length(DBSCAN_lct)
    e_location=[e_location;IDX_2{1,DBSCAN_lct(i)}];    
end
for i=1:1:size(e_location,1)
    e=e_location(i,:);
    e=e(e~=0);
    x1=coordinatez(e,1);y1=coordinatez(e,2);z1=coordinatez(e,3);
    data_shunxu=sortrows([x1,y1,z1],1);      
    x=data_shunxu(:,1);y=data_shunxu(:,2);z=data_shunxu(:,3);
    unique_x=unique(x);       
    for j=1:length(unique_x)
        idx=(x==unique_x(j));      
        [max_z(j),idz(j)]=max(z(idx));     
        if j>=2&&j<=length(unique_x)
            idz(j)=length(x(x<=unique_x(j-1)))+idz(j);   
        end
    end
    varName=sprintf('rowz_%d', i);    
    eval([varName '=data_shunxu(idz(1:length(unique_x)),1:2)']);    
end
VOL=0;    
for i=1:1:size(e_location,1)
    varName_1=sprintf('rowz_%d', i);      
    value=eval(varName_1);
    if max(value(:,1))-min(value(:,1))>=13&&length(value(:,1))>=10   
        suo_1=[];      
        suo_2=[];
        for k=1:1:length(value(:,2))
            if value(k,2)>max(vs)   
                suo_1(k)=k;    
            end
        end
        suo_1(suo_1==0)=[];
        value(suo_1,:)=[];      
        for m=1:1:length(value(:,2))      
            if value(m,1)>f_max||value(m,1)<f_min
                suo_2(m)=m;
            end
        end
        suo_2(suo_2==0)=[];
        value(suo_2,:)=[];     
        if ~isempty(value)
            VOL=VOL+1;   
            varName_n=sprintf('rowz1_%d', VOL);      
            eval([varName_n '=value(:,1:2)']);      
        end
    end
end
%% x component sort
pf_pp=zeros(POL,2);
for i=1:1:POL
    varName_p=sprintf('rowx1_%d', i);      
    value=eval(varName_p);
    pf_pp(i,1)=i;
    pf_pp(i,2)=value(1,1);
end
pf_sortx=sortrows(pf_pp,2);    
pinsan_suo=0;
for i=1:1:POL
    j=pf_sortx(i,1);
    varName_pn=sprintf('rowx1_%d', j);      
    value=eval(varName_pn);
    pinsan_suo=pinsan_suo+1;
    value(:,1)=value(:,1)-ones(length(value(:,1)),1);
    varName_npp=sprintf('PINSANx_%d', pinsan_suo);    
    eval([varName_npp '=value(:,1:2)']);   
end
%% z component sort
pf_ppz=zeros(VOL,2);
for i=1:1:VOL
    varName_pz=sprintf('rowz1_%d', i);     
    value=eval(varName_pz);
    pf_ppz(i,1)=i;
    pf_ppz(i,2)=value(1,1);
end
pf_sort=sortrows(pf_ppz,2);    
pinsan_suoz=0;
for i=1:1:VOL
    j=pf_sort(i,1);
    varName_pnz=sprintf('rowz1_%d', j);     
    value=eval(varName_pnz);
    pinsan_suoz=pinsan_suoz+1;
    value(:,1)=value(:,1)-ones(length(value(:,1)),1);
    varName_nppz=sprintf('PINSANz_%d', pinsan_suoz);      
    eval([varName_nppz '=value(:,1:2)']);    
end
%% processing
PVL=min(POL,VOL);
PML=max(POL,VOL);
for i=1:1:PVL
    varName_x=sprintf('PINSANx_%d', i);     
    varName_z=sprintf('PINSANz_%d', i);      
    pin_x=eval(varName_x);
    pin_z=eval(varName_z);
    pin=[pin_x;pin_z];
    X_pin=pin(:,1);
    Y_pin=pin(:,2);
    pin_shunxu=sortrows([X_pin,Y_pin],1);     
    pin_X=pin_shunxu(:,1);pin_Y=pin_shunxu(:,2);
    unique_pinx=unique(pin_X);     
    pinsan=[];
    for j=1:length(unique_pinx)
        idpinx=(pin_X==unique_pinx(j));     
        if length(pin_Y(idpinx))>=2
            pin_y_Y=pin_Y(idpinx);
            pinsan=[pinsan;unique(pin_X(idpinx)),(0.5*pin_y_Y(1)+0.5*pin_y_Y(2));];
        else
            pinsan=[pinsan;unique(pin_X(idpinx)),pin_Y(idpinx);];
        end
    end
    varName_f=sprintf('pinsan_%d', i);     
    eval([varName_f '=pinsan(:,1:2)']);      
end
if POL>VOL
    for i=VOL+1:1:POL
        varName_x_1=sprintf('PINSANx_%d', i);
        value=eval(varName_x_1);
        varName_x_2=sprintf('pinsan_%d', i);      
        eval([varName_x_2 '=value(:,1:2)']);
    end
end
if VOL>POL
    for i=POL+1:1:VOL
        varName_z_1=sprintf('PINSANz_%d', i);
        value=eval(varName_z_1);
        varName_z_2=sprintf('pinsan_%d', i);     
        eval([varName_z_2 '=value(:,1:2)']);
    end
end
%% denoise
for i=1:1:PML
    varName_z_n=sprintf('pinsan_%d', i);
    value=eval(varName_z_n);
    suo=[];
    for j=2:1:length(value(:,2))-1      
        if abs(value(j-1,2)+value(j+1,2)-2*value(j,2))>=60   
            suo(j)=j;    
        end
    end
    suo(suo==0)=[];
    value(suo,:)=[];      
    varName_z_n2=sprintf('Pinsan_%d', i);  
    eval([varName_z_n2 '=value(:,1:2)']);
end

for i=1:1:POL
    varName_x=sprintf('PINSANx_%d', i);     
    value=eval(varName_x);
    figure(3)
    scatter(value(:,1),value(:,2),12,'filled')
    hold on;
    xlim([f_min,f_max]);
    ylim([v_min,v_max]);
    grid on;
    xlabel('Frequency (Hz)');
    ylabel('Phase velocity (m/s)');
end
for i=1:1:VOL
    varName_z=sprintf('PINSANz_%d', i);    
    value=eval(varName_z);
    figure(4)
    scatter(value(:,1),value(:,2),12,'filled')
    hold on;
    xlim([f_min,f_max]);
    ylim([v_min,v_max]);
    grid on;
    xlabel('Frequency (Hz)');
    ylabel('Phase velocity (m/s)');
end

varName_x=sprintf('PINSANx_%d', 2);
varName_z=sprintf('PINSANz_%d', 2);
varname_xz=sprintf('Pinsan_%d', 2);
value_x=eval(varName_x);
value_z=eval(varName_z);
value_xz=eval(varname_xz);
figure(8)
scatter(value_x(:,1),value_x(:,2),22,'filled')
hold on
scatter(value_z(:,1),value_z(:,2),22,'filled')
hold on
scatter(value_xz(:,1),value_xz(:,2),22,'filled')
grid on;
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
xlim([10,21]);
ylim([280,350]);
legend('X Component','Z Component','Aggregation')
vs=parameter(1,:);  
vp=parameter(2,:);    
den=parameter(3,:);  
h=parameter(4,1:length(parameter(1,:))-1);  
fr=[f_min:f_max];  
for i=1:1:PML
    varName_2=sprintf('Pinsan_%d', i);   
    value=eval(varName_2);
    [frback,vrback]=disper(vs,vp,den,h,fr,i);
    figure(5)
    scatter(value(:,1),value(:,2),12,'filled')
    hold on;
    xlim([f_min,f_max]);
    ylim([v_min,v_max]);
    grid on;
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
end
figure(5)
imagesc([f_min,f_max],[v_min,v_max],Z);
hold on;
for i=1:1:VOL
    varName_4=sprintf('PINSANz_%d', i);   
    value=eval(varName_4);
    scatter(value(:,1),value(:,2),12,'w','filled');
    hold on;
end
set(gca,'Ydir','normal');
ylim([150,400]);
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
h=colorbar;
set(gca, 'Position', get(gca, 'Position'));  
set(gcf, 'Position', get(gcf, 'Position') + [0, 0, 100, 0]);  
figure(6)
imagesc([f_min,f_max],[v_min,v_max],X);
hold on;
for i=1:1:POL
    varName_4=sprintf('PINSANx_%d', i);     
    value=eval(varName_4);
    scatter(value(:,1),value(:,2),12,'w','filled');
    hold on;
end
set(gca,'Ydir','normal');
ylim([150,400]);
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
h=colorbar;
set(gca, 'Position', get(gca, 'Position')); 
set(gcf, 'Position', get(gcf, 'Position') + [0, 0, 100, 0]);  
figure(7)
imagesc([f_min,f_max],[v_min,v_max],S);
hold on;
for i=1:1:PML
    varName_4=sprintf('Pinsan_%d', i);      
    value=eval(varName_4);
    if i>1
        value=smooth_curve(value,0.3);
    end
    scatter(value(:,1),value(:,2),12,'w','filled');
    hold on;
end
set(gca,'Ydir','normal');
ylim([150,400]);
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
h=colorbar;
set(gca, 'Position', get(gca, 'Position'));
set(gcf, 'Position', get(gcf, 'Position') + [0, 0, 100, 0]);  