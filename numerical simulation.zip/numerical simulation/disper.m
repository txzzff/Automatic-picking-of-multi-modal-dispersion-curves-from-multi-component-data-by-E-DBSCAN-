%%****************************************************************************
%
%  PROGRAM: Forward method to calculate Rayleigh-wave dispersion curve of a
%           given mode
%
%  Author: Yudi Pan
%  Modify history:
%  12/18/2011  Yudi Pan   Initial coding
%  PURPOSE:  
%  Reference:  
% 
%
%  Parameters Description:

%**************************************************************************

function [frback,vrback]=disper4(vs,vp,den,h,fr,mode)    % original algorithm
global fcut;
n=length(vs);
rec=0;
cont=0;
fnum=0;
fcut=100000;
i=1;  
deltav=1; 
Vmax=max(vs);
Vmin=0.8*min(vs);
[nouse,minvs]=min(vs(1:n-1));
pede=0;
i=1;
mlength=length(fr);
for frt=1:mlength 
    f=fr(frt);
    moderec=1;
  for Vr=Vmin:deltav:Vmax  
    a=feval('dispersion',Vr-0.00000001,f,vs,vp,den,h);
    b=feval('dispersion',Vr+0.99999999,f,vs,vp,den,h);
    if a==0
        if moderec==mode
        x(i)=f;
        y(i)=Vr;
        i=i+1;
        moderec=1;
        break;    
        else
            moderec=moderec+1;
        end
    elseif a*b<0
            if moderec==mode
            x(i)=f;
            y(i)=bisec('dispersion',Vr-0.00000001,Vr+0.99999999,f,vs,vp,den,h); 
            wal=y(i)/x(i);
            i=i+1;
            moderec=1;
            break;   
            else
                moderec=moderec+1;
            end
        else 
        continue
    end
  end
end
if exist('y')<1
    vrback=10000;
else
    frback=x;
    vrback=y;
end

function x=dispersion(Vr,f,vs,vp,den,h)
global fcut;
% global fcut2;
global rec;
n=length(vs);
kk=2*pi*f/Vr;    
wavel=Vr/f;
if n>=4&&vs(1)>vs(2)&&vs(2)>vs(3)
    tempa=2;
else
    [nouse,tempa]=min(vs(1:n-1));
end
if f>=fcut
%     if rec==0
       n=tempa;
%        rec=1;
%     end
end
if rec==1
%     if fcut2~=0
%         [nouse,tempb]=min(vs(1:n-1));
%         if f>=fcut2
%             n=tempb;
%             rec=2;
%         end
%     end
end
for k=1:n
    rp(k)=sqrt(Vr^2/vp(k)^2-1);
    rs(k)=sqrt(Vr^2/vs(k)^2-1);
    r(k)=1-Vr^2/(2*(vs(k)^2));
    g(k)=1-r(k);
end
for k=1:n-1
    rr(k)=rp(k)^2;
    s(k)=rs(k)^2;
    p(k)=rp(k)*kk*h(k);
    q(k)=rs(k)*kk*h(k);
    a(k)=cos(p(k));
    b(k)=cos(q(k));
    c(k)=sin(p(k))/rp(k);
    d(k)=sin(q(k))/rs(k);
    l(k)=vs(k+1)^2*den(k+1)/(vs(k)^2*den(k));
end
E=zeros(5,n);
x1=1+rp(n)*rs(n);
x2=r(n)+rp(n)*rs(n);
x3=i*rs(n)*(1-r(n));
x4=i*rp(n)*(r(n)-1);
x5=-r(n)^2-rp(n)*rs(n);
E(:,n)=[x1,x2,x3,x4,x5];
for k=n-1:-1:1
M1=[1,2,0,0,-1;
    r(k),1+r(k),0,0,-1;
    0,0,g(k),0,0;
    0,0,0,g(k),0;
    -r(k)^2,-2*r(k),0,0,1];
L=[a(k)*b(k),0,-a(k)*d(k),b(k)*c(k),c(k)*d(k);
    0,1,0,0,0;
    a(k)*d(k)*s(k),0,a(k)*b(k),c(k)*d(k)*s(k),-b(k)*c(k);
    -b(k)*c(k)*rr(k),0,c(k)*d(k)*rr(k),a(k)*b(k),a(k)*d(k);
    c(k)*d(k)*rr(k)*s(k),0,b(k)*c(k)*rr(k),-a(k)*d(k)*s(k),a(k)*b(k)];
M2=[1/l(k),-2,0,0,-l(k);
    -r(k)/l(k),1+r(k),0,0,l(k);
    0,0,g(k),0,0;
    0,0,0,g(k),0;
    -r(k)^2/l(k),2*r(k),0,0,l(k)];
F=M1*L*M2;
E(:,k)=F*E(:,k+1);
end
x=real(E(5,1));

function c=bisec(fun,a,b,t,vs,vp,den,h)
delta=0.0001;
delta;
ya=feval(fun,a,t,vs,vp,den,h);
yb=feval(fun,b,t,vs,vp,den,h);
for k=1:1000   
    c=(b+a)/2;
    yc=feval(fun,c,t,vs,vp,den,h);
    if yc==0 
    break;
    elseif yb*yc>0
            b=c;
            yb=yc;
    else
        a=c;
        ya=yc;
    end
    if b-a<delta 
        break
    end
end
c=(b+a)/2;
