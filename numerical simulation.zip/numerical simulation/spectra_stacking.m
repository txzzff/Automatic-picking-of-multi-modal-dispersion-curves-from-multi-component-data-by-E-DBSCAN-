clear
clc
close all
%% read data & parameter setting
f_min=8;
f_max=80;
v_min=100;
v_max=400;
parameter=importdata('modela.txt');
vs=parameter(1,:);    % vs
vp=parameter(2,:);    % vp
den=parameter(3,:);    % density
h=parameter(4,1:length(parameter(1,:))-1);    % layer h
fr=[f_min:f_max]; 
% read data
[xmin,xmax,ymin,ymax,Z]=rdgrd('shotza.grd');
[xmin,xmax,ymin,ymax,X]=rdgrd('shotxa.grd');
set(0, 'DefaultAxesFontSize', 20);
set(0, 'DefaultTextFontSize', 22);
set(0, 'DefaultAxesFontName', 'Times New Roman');
set(0, 'DefaultTextFontName', 'Times New Roman');
%% preprocessing
X=X(v_min-ymin+1:v_max-ymin+1,f_min-xmin+1:f_max-xmin+1);
Z=Z(v_min-ymin+1:v_max-ymin+1,f_min-xmin+1:f_max-xmin+1);
S=X+Z;
figure(1)
imagesc([f_min,f_max],[v_min,v_max],Z);
set(gca,'Ydir','normal');
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
h=colorbar;
set(gca, 'Position', get(gca, 'Position'));  
set(gcf, 'Position', get(gcf, 'Position') + [0, 0, 100, 0]); 
figure(2)
imagesc([f_min,f_max],[v_min,v_max],X);
set(gca,'Ydir','normal');
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
h=colorbar;
set(gca, 'Position', get(gca, 'Position'));  
set(gcf, 'Position', get(gcf, 'Position') + [0, 0, 100, 0]);  
%% effect scatter
data=imresize(S,1);   
figure(3)
imagesc([f_min,f_max],[v_min,v_max],data);
set(gca,'Ydir','normal');
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
h=colorbar;
set(gca, 'Position', get(gca, 'Position'));  
set(gcf, 'Position', get(gcf, 'Position') + [0, 0, 100, 0]); 
[h,w]=size(data);
ave=mean(S(:));
coordinate=[];
for i=1:1:h
    for j=1:1:w
        if  data(i,j)>0
            coordinate=[coordinate;j+f_min,i+v_min,data(i,j);];
        end
    end
end
coordinate(all(coordinate==0,2),:)=[];
coordinate_1=coordinate(:,1:2);
% figure(4)
% scatter(coordinate_1(:,1),coordinate_1(:,2),8,'s','fill');
% grid on;
% xlim([f_min,f_max]);
% ylim([v_min,v_max]);
% xlabel('Frequency (Hz)');
% ylabel('Phase velocity (m/s)');
%% EDBSCAN application
IDX=EDBSCAN(coordinate,1.5,0.6); % Epsilon and MinEnergy
%% show EBDSCAN results
figure(5)
PlotClusterinResultEnhanced3(coordinate_1, IDX, f_min, f_max, v_min, v_max);
%% processing
for i=1:1:length(IDX)
    for j=1:1:max(IDX)
        if IDX(i)==j
            IDX_1{j}(i)=i;
        end
    end
end
for i=1:1:max(IDX)
    IDX_1{1,i}(IDX_1{1,i}==0)=[];
end
DBSCAN_length=zeros(1,max(IDX)); 
for i=1:1:max(IDX)
    DBSCAN_length(i)=length(IDX_1{1,i});
end
DBSCAN_lct=zeros(1,max(IDX));
for i=1:1:length(DBSCAN_length) 
    if DBSCAN_length(i)>=0.05*mean(DBSCAN_length(:))
        DBSCAN_lct(i)=(i);
    end
    DBSCAN_lct(DBSCAN_lct==0)=[];
end
for i=1:1:max(IDX)
    IDX_1{1,i}=[IDX_1{1,i},zeros(1,max(DBSCAN_length)-length(IDX_1{1,i}))];
end
e_location=[];      
for i=1:1:length(DBSCAN_lct)
    e_location=[e_location;IDX_1{1,DBSCAN_lct(i)}];    %effect location
end
for i=1:1:size(e_location,1)
    e=e_location(i,:);
    e=e(e~=0);
    x1=coordinate(e,1);y1=coordinate(e,2);z1=coordinate(e,3);
    data_shunxu=sortrows([x1,y1,z1],1);   
    x=data_shunxu(:,1);y=data_shunxu(:,2);z=data_shunxu(:,3);
    unique_x=unique(x);      
    logic_effectz=[];
    for j=1:length(unique_x)
        logic=x==unique_x(j);
        temp_x=x(logic);temp_y=y(logic);temp_z=z(logic);
        threshold_temp=0.8;   % effect scatter
        logic_1=temp_z>=threshold_temp*max(temp_z);
        logic_effectz=[logic_effectz;logic_1];
    end
    logic_effectz=logical(logic_effectz);
    varName=sprintf('rowz_%d', i);  
    eval([varName '=data_shunxu(logic_effectz,:)']);      
end
for i=1:1:size(e_location,1)
    varName_11=sprintf('rowz_%d', i);
    value=eval(varName_11);
    data_shunxu=sortrows([value(:,1),value(:,2),value(:,3)],1);      
    x=data_shunxu(:,1);y=data_shunxu(:,2);z=data_shunxu(:,3);
    data_1=data_shunxu;
    unique_xx=unique(x);
    coordinate_final=[];
    for j=1:length(unique_xx)
        logic=data_1(:,1)==unique_xx(j);
        yy=(max(data_1(logic,2))+min(data_1(logic,2)))/2;
        coordinate_final=[coordinate_final;unique_xx(j),yy];
    end
    varName=sprintf('row_%d', i);    
    eval([varName '=coordinate_final(:,1:2)']);    
end

%% Peak scatters fig
for i=1:1:size(e_location,1)
    varName_1=sprintf('row_%d', i);      
    value=eval(varName_1);
    figure(6);
    scatter(value(:,1),value(:,2),12 ,'filled');
    xlim([f_min,f_max]);
    ylim([v_min,ymax]);
    hold on;
    grid on;
    xlabel('Frequency (Hz)');
    ylabel('Phase velocity (m/s)');
end
%% denoise
POL=0; 
for i=1:1:size(e_location,1)
    varName_1=sprintf('row_%d', i);    
    value=eval(varName_1);
    if max(value(:,1))-min(value(:,1))>=12&&length(value(:,1))>=6   
        suo=[];    
        suo_1=[];      
        suo_2=[];     
        for j=2:1:length(value(:,2))-1     
            if abs(value(j-1,2)+value(j+1,2)-2*value(j,2))>=35    
                suo(j)=j;    
            end
        end
        suo(suo==0)=[];
        value(suo,:)=[];      
        for k=1:1:length(value(:,2))
            if value(k,2)>max(vs)      
                suo_1(k)=k;     
            end
        end
        suo_1(suo_1==0)=[];
        value(suo_1,:)=[];       % Guide P wave
        for m=1:1:length(value(:,2))     
            if value(m,1)>f_max||value(m,1)<f_min
                suo_2(m)=m;
            end
        end
        suo_2(suo_2==0)=[];
        value(suo_2,:)=[];     
        if ~isempty(value)
            POL=POL+1;    
            varName_n=sprintf('row2_%d', POL);     
            eval([varName_n '=value(:,1:2)']);     
        end
    end
end
POM=0;
for i=1:1:POL
    varName_z_n=sprintf('row2_%d', i);
    value=eval(varName_z_n);
    if max(value(:,1))-min(value(:,1))>=6
        POM=POM+1;
        value(:,1)=value(:,1)-ones(length(value(:,1)),1);
        varName_z_n2=sprintf('row1_%d', POM);     
        eval([varName_z_n2 '=value(:,1:2)']);
    end
end
%% dispersion curve fig
for i=1:1:POM
    varName_4=sprintf('row1_%d', i); 
    value=eval(varName_4);
    figure(8)
    
    scatter(value(:,1),value(:,2),12 ,'filled')
    hold on;
    xlim([f_min,f_max]);
    ylim([v_min,v_max]);
    grid on;
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');

end
figure(9)
imagesc([f_min,f_max],[v_min,v_max],S);
hold on;
for i=1:1:POM
    varName_4=sprintf('row1_%d', i)
    value=eval(varName_4);
    if i>1
        value=smooth_curve(value,0.3);
    end
    scatter(value(:,1),value(:,2),12,'w','filled');
    hold on;
end
    set(gca,'Ydir','normal');
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
    h=colorbar;
    set(gca, 'Position', get(gca, 'Position'));
set(gcf, 'Position', get(gcf, 'Position') + [0, 0, 100, 0]); 
%% sort
pf_pp=zeros(POM,2);
for i=1:1:POM
    varName_p=sprintf('row1_%d', i);     
    value=eval(varName_p);
    pf_pp(i,1)=i;
    pf_pp(i,2)=value(1,1);
end
pf_sort=sortrows(pf_pp,2);    
pinsan_suo=0;
for i=1:1:POM
    j=pf_sort(i,1);
    varName_pn=sprintf('row1_%d', j);      
    value=eval(varName_pn);
    pinsan_suo=pinsan_suo+1;
    varName_npp=sprintf('PINSAN_%d', pinsan_suo);    
    eval([varName_npp '=value(:,1:2)']);
end
%% pick vs theory
vs=parameter(1,:);    % 横波速度
vp=parameter(2,:);    % 纵波速度
den=parameter(3,:);    % 密度
h=parameter(4,1:length(parameter(1,:))-1);    % 地层厚度
fr=[f_min:f_max];     % 频率范围
for i=1:1:POM
    varName_2=sprintf('PINSAN_%d', i);      % 读取去噪后的有效数据
    value=eval(varName_2);
    step=0.5;      % 设置插值步长（不宜太小会导致曲线产生不必要的波动）
    if i>1
        value=smooth_curve(value,0.3);
    end
    x_1=value(:,1);y_1=value(:,2);
    x_new=x_1(1):step:x_1(end);
    y_new=spline(x_1,y_1,x_new);      %三次样条插值方法
    [frback,vrback]=disper(vs,vp,den,h,fr,i);% disper函数输出正演频散曲线频率frback与速度vrback
    figure(7);
    plot(x_1,y_1,'ko','MarkerSize',5,'Linewidth',1);
    hold on;
%     plot(x_new, y_new, 'k-');
%     hold on;
    plot(frback,vrback,'k-','Linewidth',1)
%     ,'x','MarkerSize',5
    hold on;
    xlim([f_min,f_max]);
    ylim([v_min,max(vs)+100]);
    grid on;
end
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
legend( 'Picked value', 'Theoretical value','Location', 'northwest');
set(gca, 'Position', get(gca, 'Position')); 
set(gcf, 'Position', get(gcf, 'Position') + [0, 0, 100, 0]);
%% quantitive analysis
% theta=[];  
% theta2=[];    
% feng_du=[];
% for i=1:1:POM
%     varName_wucha=sprintf('PINSAN_%d', i);    
%     value_nf=eval(varName_wucha);
%     [frback_1,vrback_1]=disper(vs,vp,den,h,fr,i) ;
%     thita_1=[];    
%     thita_2=[];    
%     for j=1:1:length(value_nf(:,1))
%         idf=(frback_1==value_nf(j,1));
%         thita_1(j)=abs(vrback_1(idf)-value_nf(j,2));
%         thita_2(j)=abs(vrback_1(idf)-value_nf(j,2))/vrback_1(idf);
%     end
%     theta(i)=sum(thita_1)/length(value_nf(:,1));
%     theta2(i)=sum(thita_2)/length(value_nf(:,1));
%     feng_du(i)=j;
% end
% B=length(feng_du);
% feng_du(B+1)=sum(feng_du);