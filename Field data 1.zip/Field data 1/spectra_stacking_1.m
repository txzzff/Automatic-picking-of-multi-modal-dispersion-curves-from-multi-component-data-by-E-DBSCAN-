clc;
clear;
close all;
%% data reading and parameter setting
Threshold_1=2.65;     
epsilon=2.8;           
MinPts=10;           
Minenergy=16;
f_min=5;
f_max=50;
v_min=50;
v_max=500;
[xmin,xmax,ymin,ymax,back2z]=rdgrd('7kkz.grd');
[xmin,xmax,ymin,ymax,back2x]=rdgrd('7kkx.grd');
set(0, 'DefaultAxesFontSize', 20);
set(0, 'DefaultTextFontSize', 22);
set(0, 'DefaultAxesFontName', 'Times New Roman');
set(0, 'DefaultTextFontName', 'Times New Roman');
%% spectrum preprocessing
back2z=back2z(v_min-ymin+1:v_max-ymin+1,f_min-xmin+1:f_max-xmin+1);
back2x=back2x(v_min-ymin+1:v_max-ymin+1,f_min-xmin+1:f_max-xmin+1);
S=back2z+back2x;
S1=back2z+back2x;
figure(1)
clims = [min(back2z(:)), max(back2z(:))]
imagesc([f_min,f_max],[v_min,v_max],imresize(back2z,100),clims);
set(gca,'Ydir','normal');
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
xticklabels({'10', '20', '30', '40', '50'});  
yticklabels({'100','200','300','400','500'}); 
h=colorbar;
% colormap jet
set(gca, 'Position', get(gca, 'Position'));  
set(gcf, 'Position', get(gcf, 'Position') + [0, 0, 75, 0]);  
figure(2)
clims = [min(back2x(:)), max(back2x(:))]
imagesc([f_min,f_max],[v_min,v_max],imresize(back2x,100),clims);
set(gca,'Ydir','normal');
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
xticklabels({'10', '20', '30', '40', '50'});   
yticklabels({'100','200','300','400','500'}); 
h=colorbar;
% colormap jet
set(gca, 'Position', get(gca, 'Position'));  
set(gcf, 'Position', get(gcf, 'Position') + [0, 0, 75, 0]);  

figure(3)
clims = [min(S1(:)), max(S1(:))]
imagesc([f_min,f_max],[v_min,v_max],imresize(S1,100),clims);
set(gca,'Ydir','normal');
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
xticklabels({'10', '20', '30', '40', '50'});   
yticklabels({'100','200','300','400','500'}); 
h=colorbar;
colormap jet
set(gca, 'Position', get(gca, 'Position')); 
set(gcf, 'Position', get(gcf, 'Position') + [0, 0, 75, 0]);  
%% clustering
data=imresize(S,1);      
[h,w]=size(data);
ave=mean(S(:));
coordinate=[];
for i=1:1:h
    for j=1:1:w
        if  data(i,j)>Threshold_1*ave*0
            coordinate=[coordinate;j+f_min,i+v_min,data(i,j);];
        end
    end
end
coordinate(all(coordinate==0,2),:)=[];      
coordinate_1=coordinate(:,1:2);      
figure(8)
scatter(coordinate_1(:,1),coordinate_1(:,2),8,'s','fill');
grid on;
xlim([f_min,f_max]);
ylim([v_min,ymax]);
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');    
IDX=EDBSCAN(coordinate,1,2);
figure(9)
PlotClusterinResultEnhanced3(coordinate_1, IDX, f_min, f_max, v_min, v_max);         
%% cluster result processing
for i=1:1:length(IDX)      
    for j=1:1:max(IDX)
        if IDX(i)==j
            IDX_1{j}(i)=i;
        end
    end
end
for i=1:1:max(IDX)
    IDX_1{1,i}(IDX_1{1,i}==0)=[]; 
end
DBSCAN_length=zeros(1,max(IDX));      
for i=1:1:max(IDX)
    DBSCAN_length(i)=length(IDX_1{1,i});
end
DBSCAN_lct=zeros(1,max(IDX));
Threshold_2=0.05;
for i=1:1:length(DBSCAN_length)      
    if DBSCAN_length(i)>=Threshold_2*mean(DBSCAN_length(:))
        DBSCAN_lct(i)=(i);
    end
    DBSCAN_lct(DBSCAN_lct==0)=[];
end
for i=1:1:max(IDX)
    IDX_1{1,i}=[IDX_1{1,i},zeros(1,max(DBSCAN_length)-length(IDX_1{1,i}))];
end
e_location=[];     
for i=1:1:length(DBSCAN_lct)
    e_location=[e_location;IDX_1{1,DBSCAN_lct(i)}];   
end
for i=1:1:size(e_location,1)
    e=e_location(i,:);
    e=e(e~=0);
    x1=coordinate(e,1);y1=coordinate(e,2);z1=coordinate(e,3);
    data_shunxu=sortrows([x1,y1,z1],1);     
    x=data_shunxu(:,1);y=data_shunxu(:,2);z=data_shunxu(:,3);
    unique_x=unique(x);       
    logic_effectz=[];
    for j=1:length(unique_x)
        logic=x==unique_x(j);
        temp_x=x(logic);temp_y=y(logic);temp_z=z(logic);
        threshold_temp=0.8;    
        logic_1=temp_z>=threshold_temp*max(temp_z);
        logic_effectz=[logic_effectz;logic_1];
    end
    logic_effectz=logical(logic_effectz);
    varName=sprintf('rowz_%d', i);      
    eval([varName '=data_shunxu(logic_effectz,:)']);      
end
for i=1:1:size(e_location,1)
    varName_11=sprintf('rowz_%d', i);
    value=eval(varName_11);
    data_shunxu=sortrows([value(:,1),value(:,2),value(:,3)],1);      
    x=data_shunxu(:,1);y=data_shunxu(:,2);z=data_shunxu(:,3);
    data_1=data_shunxu;
    unique_xx=unique(x);
    coordinate_final=[];
    for j=1:length(unique_xx)
        logic=data_1(:,1)==unique_xx(j);
        yy=(max(data_1(logic,2))+min(data_1(logic,2)))/2;
        coordinate_final=[coordinate_final;unique_xx(j),yy];
    end
    varName=sprintf('row_%d', i);     
    eval([varName '=coordinate_final(:,1:2)']);      
end

%% denoise
POL=0;     
for i=1:1:size(e_location,1)
    varName_1=sprintf('row_%d', i);    
    value=eval(varName_1);
    if max(value(:,1))-min(value(:,1))>=10&&length(value(:,1))>=6      
        suo=[];    
        suo_1=[];      
        suo_2=[];      
        for j=2:1:length(value(:,2))-1      
            if abs(value(j-1,2)+value(j+1,2)-2*value(j,2))>=20    
                suo(j)=j;    
            end
        end
        suo(suo==0)=[];
        value(suo,:)=[];     
        for m=1:1:length(value(:,2))    
            if value(m,1)>f_max||value(m,1)<f_min
                suo_2(m)=m;
            end
        end
        suo_2(suo_2==0)=[];
        value(suo_2,:)=[];      
        if ~isempty(value)
            POL=POL+1;      
            varName_n=sprintf('row2_%d', POL);     
            eval([varName_n '=value(:,1:2)']);   
        end
    end
end
POM=0;
for i=1:1:POL
    varName_z_n=sprintf('row2_%d', i);
    value=eval(varName_z_n);
    if max(value(:,1))-min(value(:,1))>=8&&length(value(:,1))>=6 
        POM=POM+1;
        value(:,1)=value(:,1)-ones(length(value(:,1)),1);
        varName_z_n2=sprintf('row1_%d', POM);
        eval([varName_z_n2 '=value(:,1:2)']);
    end
end
%% dispersion curve plot
figure(11)
clims = [min(S1(:)), max(S1(:))]
imagesc([f_min,f_max],[v_min,v_max],imresize(S1,100),clims);
hold on;
for i=1:1:POM
    varName_4=sprintf('row1_%d', i);     
    value=eval(varName_4);
    value=smooth_curve(value,0.4);
    % plot(value(:,1),value(:,2),'-wo','linewidth',2,'markersize',3.5);
    % plot(value(:,1),value(:,2),'wo','markersize',2);
    scatter(value(:,1),value(:,2),16,'w','filled');
    hold on;
    plot(value(:,1),value(:,2),'w','LineWidth',2)
    hold on;
end
    set(gca,'Ydir','normal');
    xlabel('Frequency (Hz)');
    ylabel('Phase velocity (m/s)');
    h=colorbar;
    xticklabels({'10', '20', '30', '40', '50'});  
    yticklabels({'100','200','300','400','500'});
    % colormap jet
    set(gca, 'Position', get(gca, 'Position'));  
    set(gcf, 'Position', get(gcf, 'Position') + [0, 0, 75, 0]);  