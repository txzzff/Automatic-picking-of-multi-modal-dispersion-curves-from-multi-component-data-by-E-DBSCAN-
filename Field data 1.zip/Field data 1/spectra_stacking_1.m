clc;
clear;
close all;
%% 参数设置与数据读取
% 去噪阈值参数
Threshold_1=2.65;      % （[1,2]）分离频散能量与背景噪声的阈值
% 若仅能拾取基阶的频散曲线，则调小阈值，若曲线识别有误或噪声过大，则调大阈值
% DBSCAN密度聚类参数
epsilon=2.8;             % 定义密度时的邻域半径（[3-5]）
MinPts=10;             % 定义核心点时的阈值（[8,15]）
Minenergy=16;
% 设置频率范围
f_min=5;
f_max=50;
% 设置速度范围
v_min=50;
v_max=500;
% 读取z分量频散能量图
[xmin,xmax,ymin,ymax,back2z]=rdgrd('7kkz.grd');
[xmin,xmax,ymin,ymax,back2x]=rdgrd('7kkx.grd');
set(0, 'DefaultAxesFontSize', 20);
set(0, 'DefaultTextFontSize', 22);
set(0, 'DefaultAxesFontName', 'Times New Roman');
set(0, 'DefaultTextFontName', 'Times New Roman');
%% 频散能谱预处理
% % 取相应频率速度的x、z分量的频散能量
back2z=back2z(v_min-ymin+1:v_max-ymin+1,f_min-xmin+1:f_max-xmin+1);
back2x=back2x(v_min-ymin+1:v_max-ymin+1,f_min-xmin+1:f_max-xmin+1);
S=back2z+back2x;
S1=back2z+back2x;
figure(1)
clims = [min(back2z(:)), max(back2z(:))]
imagesc([f_min,f_max],[v_min,v_max],imresize(back2z,100),clims);
set(gca,'Ydir','normal');
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
xticklabels({'10', '20', '30', '40', '50'});   % 显示自定义标签
% yticklabels({'100', '150','200', '250','300', '350','400', '450','500'});   % 显示自定义标签
yticklabels({'100','200','300','400','500'}); 
h=colorbar;
% colormap jet
set(gca, 'Position', get(gca, 'Position'));  % 保持原位置
set(gcf, 'Position', get(gcf, 'Position') + [0, 0, 75, 0]);  % 调整图窗大小 (可根据需要调整)
figure(2)
clims = [min(back2x(:)), max(back2x(:))]
imagesc([f_min,f_max],[v_min,v_max],imresize(back2x,100),clims);
set(gca,'Ydir','normal');
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
xticklabels({'10', '20', '30', '40', '50'});   % 显示自定义标签
yticklabels({'100','200','300','400','500'}); 
h=colorbar;
% colormap jet
set(gca, 'Position', get(gca, 'Position'));  % 保持原位置
set(gcf, 'Position', get(gcf, 'Position') + [0, 0, 75, 0]);  % 调整图窗大小 (可根据需要调整)

figure(3)
clims = [min(S1(:)), max(S1(:))]
imagesc([f_min,f_max],[v_min,v_max],imresize(S1,100),clims);
set(gca,'Ydir','normal');
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
xticklabels({'10', '20', '30', '40', '50'});   % 显示自定义标签
yticklabels({'100','200','300','400','500'}); 
h=colorbar;
colormap jet
set(gca, 'Position', get(gca, 'Position'));  % 保持原位置
set(gcf, 'Position', get(gcf, 'Position') + [0, 0, 75, 0]);  % 调整图窗大小 (可根据需要调整)
%% 频散能量与背景噪声分离
data=imresize(S,1);      % 默认不放大
[h,w]=size(data);
ave=mean(S(:));
% 区分频散能量与背景噪声
% 输出频散能量点坐标与振幅
coordinate=[];% 初始化存储坐标矩阵
for i=1:1:h
    for j=1:1:w
        if  data(i,j)>Threshold_1*ave*0
            coordinate=[coordinate;j+f_min,i+v_min,data(i,j);];
        end
    end
end
coordinate(all(coordinate==0,2),:)=[];      % 删除矩阵中的0元素
coordinate_1=coordinate(:,1:2);      % 取坐标列作为DBSCAN的输入数据
figure(8)
scatter(coordinate_1(:,1),coordinate_1(:,2),8,'s','fill');
grid on;
xlim([f_min,f_max]);
ylim([v_min,ymax]);
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
% title('分离的频散能量在f-v域的坐标','FontSize',15);
%% 运行DBSCAN算法模块
%读取两个关键参数的取值
% IDX=DBSCAN(coordinate_1,epsilon,MinPts);         % 传入参数运行函数DBSCAN
IDX=EDBSCAN(coordinate,1,2);
%% DBSCAN结果运行绘图模块
figure(9)
PlotClusterinResultEnhanced3(coordinate_1, IDX, f_min, f_max, v_min, v_max);          % 传入参数，绘制图像
% xlabel('频率(Hz)','FontSize',15);
% ylabel('相速度(m/s)','FontSize',15);
% title(['DBSCAN Clustering result(\epsilon = ' num2str(epsilon) ', MinPts = ' num2str(MinPts) ')']);
%% 对DBSCAN结果进一步区分噪声与频散能量
% 将DBSCAN聚类结果的每一类分开，将坐标数值索引存放在元胞数组IDX_1中
for i=1:1:length(IDX)      % 循环中产生多余0元素
    for j=1:1:max(IDX)
        if IDX(i)==j
            IDX_1{j}(i)=i;
        end
    end
end
for i=1:1:max(IDX)
    IDX_1{1,i}(IDX_1{1,i}==0)=[];  % 删除元胞数组中所有的0元素
end
% 对DBSCAN遗漏的噪声进一步去除
DBSCAN_length=zeros(1,max(IDX));      % 比较每一类的频散能量点个数
for i=1:1:max(IDX)
    DBSCAN_length(i)=length(IDX_1{1,i});
end
DBSCAN_lct=zeros(1,max(IDX));
% 去噪阈值参数
Threshold_2=0.05;% （[0.01,0.05]，对DBSCAN遗漏的噪声进行去除）
for i=1:1:length(DBSCAN_length)      % 设置频散能量投影点个数阈值消除噪声
    if DBSCAN_length(i)>=Threshold_2*mean(DBSCAN_length(:))
        DBSCAN_lct(i)=(i);
    end
    DBSCAN_lct(DBSCAN_lct==0)=[];
end
% 补零并合并频散能量点坐标序号
for i=1:1:max(IDX)
    IDX_1{1,i}=[IDX_1{1,i},zeros(1,max(DBSCAN_length)-length(IDX_1{1,i}))];
end
e_location=[];      % 初始化矩阵
for i=1:1:length(DBSCAN_lct)
    e_location=[e_location;IDX_1{1,DBSCAN_lct(i)}];    % 得到有效坐标索引矩阵
end
% 为保证采样点不重复，对每一类的每一频率值取最大频散能量坐标
for i=1:1:size(e_location,1)
    e=e_location(i,:);
    e=e(e~=0);
    x1=coordinate(e,1);y1=coordinate(e,2);z1=coordinate(e,3);
    data_shunxu=sortrows([x1,y1,z1],1);      % 将数据按x坐标的大小顺序排列
    x=data_shunxu(:,1);y=data_shunxu(:,2);z=data_shunxu(:,3);
    unique_x=unique(x);       % 取x所有的唯一值
    logic_effectz=[];
    for j=1:length(unique_x)
        logic=x==unique_x(j);
        temp_x=x(logic);temp_y=y(logic);temp_z=z(logic);
        threshold_temp=0.8;    %设置最大振幅值的阈值
        logic_1=temp_z>=threshold_temp*max(temp_z);
        logic_effectz=[logic_effectz;logic_1];
    end
    logic_effectz=logical(logic_effectz);
    % 取峰值
    % for j=1:length(unique_x)
    %     idx=(x==unique_x(j));      % 获取当前x值的索引
    %     [max_z(j),idz(j)]=max(z(idx));      % 获取当前x值对应的最大z值
    %     if j>=2&&j<=length(unique_x)
    %         idz(j)=length(x(x<=unique_x(j-1)))+idz(j);    % 获取z值在原坐标矩阵中的索引
    %     end
    % end
    varName=sprintf('rowz_%d', i);      % 创建变量名
    eval([varName '=data_shunxu(logic_effectz,:)']);      % 创建并赋值坐标
%     % 得到最终的坐标索引矩阵
end
for i=1:1:size(e_location,1)
    varName_11=sprintf('rowz_%d', i);
    value=eval(varName_11);
    data_shunxu=sortrows([value(:,1),value(:,2),value(:,3)],1);      % 将数据按x坐标的大小顺序排列
    x=data_shunxu(:,1);y=data_shunxu(:,2);z=data_shunxu(:,3);
    data_1=data_shunxu;
    % 取中值
    unique_xx=unique(x);
    coordinate_final=[];
    for j=1:length(unique_xx)
        logic=data_1(:,1)==unique_xx(j);
        yy=(max(data_1(logic,2))+min(data_1(logic,2)))/2;
        coordinate_final=[coordinate_final;unique_xx(j),yy];
    end
    varName=sprintf('row_%d', i);      % 创建变量名
    eval([varName '=coordinate_final(:,1:2)']);      % 创建并赋值坐标
end
%% DBSCAN局部峰值散点绘图
for i=1:1:size(e_location,1)
    varName_1=sprintf('row_%d', i);      % 读取数据
    value=eval(varName_1);
    figure(10);
    scatter(value(:,1),value(:,2),12 ,'filled');
    xlim([f_min,f_max]);
    ylim([v_min,ymax]);
    hold on;
    grid on;
    xlabel('Frequency (Hz)');
    ylabel('Phase velocity (m/s)');
%     title('DBSCAN每一类别对应的局部峰值散点','FontSize',15)
end
%% 频散曲线筛选与去噪
POL=0;      % 初始化索引
for i=1:1:size(e_location,1)
    varName_1=sprintf('row_%d', i);      % 读取数据
    value=eval(varName_1);
    if max(value(:,1))-min(value(:,1))>=10&&length(value(:,1))>=6      % 频率范围大于12的认定为频散曲线
        suo=[];    % 异常值索引变量
        suo_1=[];      % p导波索引变量
        suo_2=[];      % 频率异常值索引变量
        for j=2:1:length(value(:,2))-1      % 对除去两端的所有点进行遍历
            if abs(value(j-1,2)+value(j+1,2)-2*value(j,2))>=20    % 根据斜率差绝对值值剔除异常跳动的噪声值
                suo(j)=j;     % 输出异常值索引
            end
        end
        suo(suo==0)=[];
        value(suo,:)=[];      % 对异常值清零
%         for k=1:1:length(value(:,2))
%             if value(k,2)>max(vs)      % 频率成分大于s波速度最大值部分的频散能量为p导波频散能量
%                 suo_1(k)=k;      % 输出p导波成分索引
%             end
%         end
%         suo_1(suo_1==0)=[];
%         value(suo_1,:)=[];      % 清除p导波
        for m=1:1:length(value(:,2))      % 对频率异常值清除
            if value(m,1)>f_max||value(m,1)<f_min
                suo_2(m)=m;
            end
        end
        suo_2(suo_2==0)=[];
        value(suo_2,:)=[];      % 对频率异常值清除
        if ~isempty(value)
            POL=POL+1;      % 索引+1
            varName_n=sprintf('row2_%d', POL);      % 创建变量名
            eval([varName_n '=value(:,1:2)']);      % 创建并赋值坐标
        end
    end
end
POM=0;
for i=1:1:POL
    varName_z_n=sprintf('row2_%d', i);
    value=eval(varName_z_n);
    if max(value(:,1))-min(value(:,1))>=8&&length(value(:,1))>=6 
        POM=POM+1;
        value(:,1)=value(:,1)-ones(length(value(:,1)),1);
        varName_z_n2=sprintf('row1_%d', POM);      % 创建变量名
        eval([varName_z_n2 '=value(:,1:2)']);
    end
end
%% 绘制出所有频散曲线
figure(11)
clims = [min(S1(:)), max(S1(:))]
imagesc([f_min,f_max],[v_min,v_max],imresize(S1,100),clims);
hold on;
for i=1:1:POM
    varName_4=sprintf('row1_%d', i);      % 读取去噪后的有效数据
    value=eval(varName_4);
    value=smooth_curve(value,0.4);
    % plot(value(:,1),value(:,2),'-wo','linewidth',2,'markersize',3.5);
    % plot(value(:,1),value(:,2),'wo','markersize',2);
    scatter(value(:,1),value(:,2),16,'w','filled');
    hold on;
    plot(value(:,1),value(:,2),'w','LineWidth',2)
    hold on;
%     title('自动拾取的频散曲线','FontSize',15)
end
    set(gca,'Ydir','normal');
    xlabel('Frequency (Hz)');
    ylabel('Phase velocity (m/s)');
    h=colorbar;
    xticklabels({'10', '20', '30', '40', '50'});   % 显示自定义标签
    yticklabels({'100','200','300','400','500'});
    % colormap jet
    set(gca, 'Position', get(gca, 'Position'));  % 保持原位置
    set(gcf, 'Position', get(gcf, 'Position') + [0, 0, 75, 0]);  % 调整图窗大小 (可根据需要调整)
% clims = [min(S1(:)), max(S1(:))]
% imagesc([f_min,f_max],[v_min,v_max],imresize(S1,100),clims);
% set(gca,'Ydir','normal');
% xlabel('Frequency (Hz)');
% ylabel('Phase velocity (m/s)');
% xticklabels({'10', '20', '30', '40', '50'});   % 显示自定义标签
% yticklabels({'100','200','300','400','500'}); 
% h=colorbar;
% colormap jet
% set(gca, 'Position', get(gca, 'Position'));  % 保持原位置
% set(gcf, 'Position', get(gcf, 'Position') + [0, 0, 75, 0]);  % 调整图窗大小 (可根据需要调整)