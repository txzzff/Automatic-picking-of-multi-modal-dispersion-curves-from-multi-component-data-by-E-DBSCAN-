function PlotClusterinResultEnhanced(X, IDX, f_min, f_max, v_min, ymax)
    k = max(IDX);
    Colors = lines(k); % 使用 MATLAB 自带的高对比度颜色

    Legends = {};

    for i = 0:k
        Xi = X(IDX == i, :);

        if i ~= 0
            Style = 'o'; % 统一形状为圆形
            MarkerSize = 2; % 设置标记大小
            Color = Colors(i, :); % 从色图中分配颜色
            Legends{end + 1} = ['Cluster #' num2str(i)];
        else
            Style = 'o';
            MarkerSize = 2;
            Color = [0 0 0]; % 噪声点为黑色
            if ~isempty(Xi)
                Legends{end + 1} = 'Noise';
            end
        end

        if ~isempty(Xi)
            plot(Xi(:, 1), Xi(:, 2), Style, 'MarkerSize', MarkerSize, 'MarkerFaceColor', Color, 'Color', Color); % 填充颜色
        end
        hold on;
    end
    hold off;
    
    grid on;
    % legend(Legends, 'Location', 'NorthEastOutside', 'FontSize', 10); % 调整字体大小
    xlim([f_min, f_max]);
    ylim([v_min, ymax]);
    xlabel('Frequency (Hz)', 'FontSize', 15); % 增加坐标轴标签
    ylabel('Phase velocity (m/s)', 'FontSize', 15);
    % title('Enhanced DBSCAN Clustering Result', 'FontSize', 14); % 更加清晰的标题
end
