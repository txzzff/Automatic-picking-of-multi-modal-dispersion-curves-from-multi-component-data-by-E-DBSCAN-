clear
clc
close all
%% parameter setting
% step 2 clustering parameter
epsilon_xz=1.2;  
MinPts_xz=1.5;  
f_min=5;
f_max=50;
v_min=50;
v_max=500;
% read data
[xmin,xmax,ymin,ymax,Z]=rdgrd('7kkz.grd');
[xmin,xmax,ymin,ymax,X]=rdgrd('7kkx.grd');
set(0, 'DefaultAxesFontSize', 20);
set(0, 'DefaultTextFontSize', 22);
set(0, 'DefaultAxesFontName', 'Times New Roman');
set(0, 'DefaultTextFontName', 'Times New Roman');
X=X(v_min-ymin+1:v_max-ymin+1,f_min-xmin+1:f_max-xmin+1);
Z=Z(v_min-ymin+1:v_max-ymin+1,f_min-xmin+1:f_max-xmin+1);
S=X+Z;
%% x component
datax=imresize(X,1);     
[h,w]=size(datax);
coordinatex=[];
for i=1:1:h
    for j=1:1:w
        if  datax(i,j)>0
            coordinatex=[coordinatex;j+f_min,i+v_min,datax(i,j);];
        end
    end
end
coordinatex(all(coordinatex==0,2),:)=[];      
coordinate_1=coordinatex(:,1:2);      
IDX_x=EDBSCAN(coordinatex,1.5,3);         
figure(1)
PlotClusterinResultEnhanced3(coordinate_1, IDX_x, f_min, f_max, v_min, v_max);          
for i=1:1:length(IDX_x)     
    for j=1:1:max(IDX_x)
        if IDX_x(i)==j
            IDX_1{j}(i)=i;
        end
    end
end
for i=1:1:max(IDX_x)
    IDX_1{1,i}(IDX_1{1,i}==0)=[];  
end
DBSCAN_length=zeros(1,max(IDX_x));     
for i=1:1:max(IDX_x)
    DBSCAN_length(i)=length(IDX_1{1,i});
end
DBSCAN_lct=zeros(1,max(IDX_x));
Threshold_2x=0.05;
for i=1:1:length(DBSCAN_length)      
    if DBSCAN_length(i)>=Threshold_2x*mean(DBSCAN_length(:))
        DBSCAN_lct(i)=(i);
    end
    DBSCAN_lct(DBSCAN_lct==0)=[];
end
for i=1:1:max(IDX_x)
    IDX_1{1,i}=[IDX_1{1,i},zeros(1,max(DBSCAN_length)-length(IDX_1{1,i}))];
end
ex_location=[];    
for i=1:1:length(DBSCAN_lct)
    ex_location=[ex_location;IDX_1{1,DBSCAN_lct(i)}]; 
end
for i=1:1:size(ex_location,1)
    e=ex_location(i,:);
    e=e(e~=0);
    x1x=coordinatex(e,1);y1x=coordinatex(e,2);z1x=coordinatex(e,3);
    data_shunxux=sortrows([x1x,y1x,z1x],1);      
    x=data_shunxux(:,1);y=data_shunxux(:,2);z=data_shunxux(:,3);
    unique_x=unique(x);
    logic_effectx=[];
    for j=1:length(unique_x)
        logic=x==unique_x(j);
        temp_x=x(logic);temp_y=y(logic);temp_z=z(logic);
        threshold_temp=0.7;    
        logic_1=temp_z>=threshold_temp*max(temp_z);
        logic_effectx=[logic_effectx;logic_1];
    end
    logic_effectx=logical(logic_effectx);
    varName=sprintf('rowx_%d', i);     
    eval([varName '=data_shunxux(logic_effectx,:)']);  
end
%% z component
dataz=imresize(Z,1);    
[h,w]=size(dataz);
ave_z=mean(Z(:));
coordinatez=[];
for i=1:1:h
    for j=1:1:w
        if  dataz(i,j)>0
            coordinatez=[coordinatez;j+f_min,i+v_min,dataz(i,j);];
        end
    end
end
coordinatez(all(coordinatez==0,2),:)=[];     
coordinate_2=coordinatez(:,1:2);      
IDX_z=EDBSCAN(coordinatez,1.5,0.8);
figure(2)
PlotClusterinResultEnhanced3(coordinate_2, IDX_z, f_min, f_max, v_min, v_max);
for i=1:1:length(IDX_z)     
    for j=1:1:max(IDX_z)
        if IDX_z(i)==j
            IDX_2{j}(i)=i;
        end
    end
end
for i=1:1:max(IDX_z)
    IDX_2{1,i}(IDX_2{1,i}==0)=[];
end
DBSCAN_length=zeros(1,max(IDX_z));
for i=1:1:max(IDX_z)
    DBSCAN_length(i)=length(IDX_2{1,i});
end
DBSCAN_lct=zeros(1,max(IDX_z));
Threshold_2=0.05;
for i=1:1:length(DBSCAN_length)
    if DBSCAN_length(i)>=Threshold_2*mean(DBSCAN_length(:))
        DBSCAN_lct(i)=(i);
    end
    DBSCAN_lct(DBSCAN_lct==0)=[];
end
for i=1:1:max(IDX_z)
    IDX_2{1,i}=[IDX_2{1,i},zeros(1,max(DBSCAN_length)-length(IDX_2{1,i}))];
end
e_location=[];     
for i=1:1:length(DBSCAN_lct)
    e_location=[e_location;IDX_2{1,DBSCAN_lct(i)}];    
end
for i=1:1:size(e_location,1)
    e=e_location(i,:);
    e=e(e~=0);
    x1=coordinatez(e,1);y1=coordinatez(e,2);z1=coordinatez(e,3);
    data_shunxu=sortrows([x1,y1,z1],1);     
    x=data_shunxu(:,1);y=data_shunxu(:,2);z=data_shunxu(:,3);
    unique_x=unique(x);
    logic_effectz=[];
    for j=1:length(unique_x)
        logic=x==unique_x(j);
        temp_x=x(logic);temp_y=y(logic);temp_z=z(logic);
        threshold_temp=0.8;   
        logic_1=temp_z>=threshold_temp*max(temp_z);
        logic_effectz=[logic_effectz;logic_1];
    end
    logic_effectz=logical(logic_effectz);
    varName=sprintf('rowz_%d', i);   
    eval([varName '=data_shunxu(logic_effectz,:)']);    
end
%% step 2 clustering
coordinate_xz=[];
for i=1:1:size(ex_location,1)
    varName_xz1=sprintf('rowx_%d', i);     
    value=eval(varName_xz1);
    coordinate_xz=[coordinate_xz;value];
end
for i=1:1:size(e_location,1)
    varName_xz2=sprintf('rowz_%d', i);      
    value=eval(varName_xz2);
    coordinate_xz=[coordinate_xz;value];
end
coordinate_xz=unique(coordinate_xz,'rows')
figure(3)
scatter(coordinate_xz(:,1),coordinate_xz(:,2),12,'s','fill');
grid on;
xlim([f_min,f_max]);
ylim([v_min,ymax]);
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
coordinate_xz(:,2)=coordinate_xz(:,2)/10;
IDX_xz=DBSCAN(coordinate_xz(:,1:2),epsilon_xz,MinPts_xz);         
figure(4)
PlotClusterinResultEnhanced3(coordinate_xz(:,1:2), IDX_xz, f_min, f_max, v_min/10, v_max/10);       
%% step 2 cluster result processing
for i=1:1:length(IDX_xz)      
    for j=1:1:max(IDX_xz)
        if IDX_xz(i)==j
            IDX_n{j}(i)=i;
        end
    end
end
for i=1:1:max(IDX_xz)
    IDX_n{1,i}(IDX_n{1,i}==0)=[]; 
end
DBSCAN_length=zeros(1,max(IDX_xz));     
for i=1:1:max(IDX_xz)
    DBSCAN_length(i)=length(IDX_n{1,i});
end
DBSCAN_lct=zeros(1,max(IDX_xz));
Threshold_2=0.05;  
for i=1:1:length(DBSCAN_length)     
    if DBSCAN_length(i)>=Threshold_2*mean(DBSCAN_length(:))
        DBSCAN_lct(i)=(i);
    end
    DBSCAN_lct(DBSCAN_lct==0)=[];
end
for i=1:1:max(IDX_xz)
    IDX_n{1,i}=[IDX_n{1,i},zeros(1,max(DBSCAN_length)-length(IDX_n{1,i}))];
end
exz_location=[];     
for i=1:1:length(DBSCAN_lct)
    exz_location=[exz_location;IDX_n{1,DBSCAN_lct(i)}];  
end
for i=1:1:size(exz_location,1)
    e=exz_location(i,:);
    e=e(e~=0);
    x1=coordinate_xz(e,1);y1=coordinate_xz(e,2);z1=coordinate_xz(e,3);
    data_shunxu_xz=sortrows([x1,y1,z1],1);      
    x=data_shunxu_xz(:,1);y=data_shunxu_xz(:,2);z=data_shunxu_xz(:,3);
    data_1=data_shunxu_xz;
    unique_xx=unique(x);
    coordinate_final=[];
    for j=1:length(unique_xx)
        logic=data_1(:,1)==unique_xx(j);
        yy=(max(data_1(logic,2))+min(data_1(logic,2)))/2;
        coordinate_final=[coordinate_final;unique_xx(j),yy];
    end
    varName=sprintf('row_%d', i);      
    eval([varName '=coordinate_final(:,1:2)']);      
end
%% denoise
POM=0;   
for i=1:1:size(exz_location,1)    
    varName_z_n=sprintf('row_%d', i);
    value=eval(varName_z_n);
    if max(value(:,1))-min(value(:,1))>=7
        suo=[];    
        suo_2=[];
        for j=2:1:length(value(:,2))-1      
            if abs(value(j-1,2)+value(j+1,2)-2*value(j,2))>=100   
                suo(j)=j;     
            end
        end
        suo(suo==0)=[];
        value(suo,:)=[];     
        for m=1:1:length(value(:,2))      
            if value(m,1)>f_max||value(m,1)<f_min
                suo_2(m)=m;
            end
        end
        suo_2(suo_2==0)=[];
        value(suo_2,:)=[];      
        if ~isempty(value)&&max(value(:,1))-min(value(:,1))>8
        POM=POM+1;
        value(:,2)=value(:,2)*10;
        value(:,1)=value(:,1)-ones(length(value(:,1)),1);
        varName_z_n2=sprintf('pinsan_%d', POM);     
        eval([varName_z_n2 '=value(:,1:2)']);
        end
    end
end
%% plot dispersion curve
for i=1:1:POM
    varName_4=sprintf('pinsan_%d', i);      
    value=eval(varName_4);
    figure(5)
    scatter(value(:,1),value(:,2),12 ,'filled')
    hold on;
    xlim([f_min,f_max]);
    ylim([v_min,v_max]);
    grid on;
    xlabel('Frequency (Hz)');
    ylabel('Phase velocity (m/s)');
end
Pinsan=cell(POM,1);
figure(6)
clims = [min(S(:)), max(S(:))]
imagesc([f_min,f_max],[v_min,v_max],imresize(S,100),clims);
hold on;
for i=1:1:POM
    varName_4=sprintf('pinsan_%d', i);     
    value=eval(varName_4);
    value=smooth_curve(value,0.4);
    Pinsan{i}=value;
    scatter(value(:,1),value(:,2),16,'w','filled');
    hold on;
    plot(value(:,1),value(:,2),'w','LineWidth',2)
    hold on;
end
set(gca,'Ydir','normal');
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
h=colorbar;
xticklabels({'10', '20', '30', '40', '50'});   
yticklabels({'100','200','300','400','500'});
% colormap jet
set(gca, 'Position', get(gca, 'Position'));  
set(gcf, 'Position', get(gcf, 'Position') + [0, 0, 75, 0]);  
figure(7)
clims = [min(X(:)), max(X(:))]
imagesc([f_min,f_max],[v_min,v_max],imresize(X,100),clims);
set(gca,'Ydir','normal');
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
h=colorbar;
xticklabels({'10', '20', '30', '40', '50'});   
yticklabels({'100','200','300','400','500'});
% colormap jet
set(gca, 'Position', get(gca, 'Position'));  
set(gcf, 'Position', get(gcf, 'Position') + [0, 0, 75, 0]);  

figure(8)
clims = [min(Z(:)), max(Z(:))]
imagesc([f_min,f_max],[v_min,v_max],imresize(Z,100),clims);
set(gca,'Ydir','normal');
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
h=colorbar;
xticklabels({'10', '20', '30', '40', '50'});   
yticklabels({'100','200','300','400','500'});
% colormap jet
set(gca, 'Position', get(gca, 'Position'));  
set(gcf, 'Position', get(gcf, 'Position') + [0, 0, 75, 0]);  