clc;
clear;
close all;
%% 参数设置与数据读取
% 去噪阈值参数
Threshold_x=1.65;      % （[1,2]）分离频散能量与背景噪声的阈值
Threshold_z=1.65;      % （[1,2]）分离频散能量与背景噪声的阈值
% 若仅能拾取基阶的频散曲线，则调小阈值，若曲线识别有误或噪声过大，则调大阈值
% DBSCAN密度聚类参数
% x分量
epsilon_x=3;      % 定义密度时的邻域半径（[3，5]）
MinPts_x=12;      % 定义核心点时的阈值（[8,15]）
% z分量
epsilon_z=4;      % 定义密度时的邻域半径（[3，5]）
MinPts_z=12;      % 定义核心点时的阈值（[8,15]）
% 设置频率范围
f_min=5;
f_max=50;
% 设置速度范围
v_min=50;
v_max=500;
% 读取地层数据
% parameter=importdata('modela.txt');
% % 地层模型参数设置
% vs=parameter(1,:);    % 横波速度
% vp=parameter(2,:);    % 纵波速度
% den=parameter(3,:);    % 密度
% h=parameter(4,1:length(parameter(1,:))-1);    % 地层厚度
fr=[f_min:f_max];     % 频率范围
% 读取z分量频散能量图
[xmin,xmax,ymin,ymax,Z]=rdgrd('7kkz.grd');
% 读取x分量频散能量图z
[xmin,xmax,ymin,ymax,X]=rdgrd('7kkx.grd');
set(0, 'DefaultAxesFontSize', 20);
set(0, 'DefaultTextFontSize', 22);
set(0, 'DefaultAxesFontName', 'Times New Roman');
set(0, 'DefaultTextFontName', 'Times New Roman');
%% 频散能谱预处理
% 取相应频率速度的x、z分量的频散能量
X=X(v_min-ymin+1:v_max-ymin+1,f_min-xmin+1:f_max-xmin+1);
Z=Z(v_min-ymin+1:v_max-ymin+1,f_min-xmin+1:f_max-xmin+1);
S=X+Z;
%% 对x分量进行处理
datax=imresize(X,1);      % 默认不放大
[h,w]=size(datax);
ave_x=mean(X(:));
% 区分频散能量与背景噪声
% 输出频散能量点坐标与振幅
coordinatex=[];% 初始化存储坐标矩阵
for i=1:1:h
    for j=1:1:w
        if  datax(i,j)>Threshold_x*ave_x
            coordinatex=[coordinatex;j+f_min,i+v_min,datax(i,j);];
        end
    end
end
coordinatex(all(coordinatex==0,2),:)=[];      % 删除矩阵中的0元素
coordinate_1=coordinatex(:,1:2);      % 取坐标列作为DBSCAN的输入数据
%读取两个关键参数的取值
IDX_x=DBSCAN(coordinate_1,epsilon_x,MinPts_x);         % 传入参数运行函数DBSCAN
figure(1)
PlotClusterinResult(coordinate_1, IDX_x, f_min, f_max, v_min, v_max);          % 传入参数，绘制图像
% xlabel('频率(Hz)','FontSize',15);
% ylabel('相速度(m/s)','FontSize',15);
% title(['X DBSCAN Clustering result(\epsilon = ' num2str(epsilon_x) ', MinPts = ' num2str(MinPts_x) ')']);
% 将DBSCAN聚类结果的每一类分开，将坐标数值索引存放在元胞数组IDX_1中
for i=1:1:length(IDX_x)      % 循环中产生多余0元素
    for j=1:1:max(IDX_x)
        if IDX_x(i)==j
            IDX_1{j}(i)=i;
        end
    end
end
for i=1:1:max(IDX_x)
    IDX_1{1,i}(IDX_1{1,i}==0)=[];  % 删除元胞数组中所有的0元素
end
% 对DBSCAN遗漏的噪声进一步去除
DBSCAN_length=zeros(1,max(IDX_x));      % 比较每一类的频散能量点个数
for i=1:1:max(IDX_x)
    DBSCAN_length(i)=length(IDX_1{1,i});
end
DBSCAN_lct=zeros(1,max(IDX_x));
% 去噪阈值参数
Threshold_2x=0.05;% （[0.01,0.05]，对DBSCAN遗漏的噪声进行去除）
for i=1:1:length(DBSCAN_length)      % 设置频散能量投影点个数阈值消除噪声
    if DBSCAN_length(i)>=Threshold_2x*mean(DBSCAN_length(:))
        DBSCAN_lct(i)=(i);
    end
    DBSCAN_lct(DBSCAN_lct==0)=[];
end
% 补零并合并频散能量点坐标序号
for i=1:1:max(IDX_x)
    IDX_1{1,i}=[IDX_1{1,i},zeros(1,max(DBSCAN_length)-length(IDX_1{1,i}))];
end
ex_location=[];      % 初始化矩阵
for i=1:1:length(DBSCAN_lct)
    ex_location=[ex_location;IDX_1{1,DBSCAN_lct(i)}];    % 得到有效坐标索引矩阵
end
% 为保证采样点不重复，对每一类的每一频率值取最大频散能量坐标
for i=1:1:size(ex_location,1)
    e=ex_location(i,:);
    e=e(e~=0);
    x1x=coordinatex(e,1);y1x=coordinatex(e,2);z1x=coordinatex(e,3);
    data_shunxux=sortrows([x1x,y1x,z1x],1);      % 将数据按x坐标的大小顺序排列
    x=data_shunxux(:,1);y=data_shunxux(:,2);z=data_shunxux(:,3);
    unique_x=unique(x);       % 取x所有的唯一值
    for j=1:length(unique_x)
        idx=(x==unique_x(j));      % 获取当前x值的索引
        [max_z(j),idz(j)]=max(z(idx));      % 获取当前x值对应的最大z值
        if j>=2&&j<=length(unique_x)
            idz(j)=length(x(x<=unique_x(j-1)))+idz(j);    % 获取z值在原矩阵中的索引
        end
    end
    varName=sprintf('rowx_%d', i);      % 创建变量名
    eval([varName '=data_shunxux(idz(1:length(unique_x)),1:2)']);      % 创建并赋值坐标
%     % 得到最终的坐标索引矩阵
end
POL=0;      % 初始化索引
for i=1:1:size(ex_location,1)
    varName_1=sprintf('rowx_%d', i);      % 读取数据
    value=eval(varName_1);
    if max(value(:,1))-min(value(:,1))>=12&&length(value(:,1))>=10      % 频率范围大于12的认定为频散曲线
        suo=[];    % 异常值索引变量
        suo_1=[];      % p导波索引变量
        suo_2=[];
        for j=2:1:length(value(:,2))-1      % 对除去两端的所有点进行遍历
            if abs(value(j-1,2)+value(j+1,2)-2*value(j,2))>=100    % 根据斜率差绝对值值剔除异常跳动的噪声值
                suo(j)=j;     % 输出异常值索引
            end
        end
        suo(suo==0)=[];
        value(suo,:)=[];      % 对异常值清零
        % for k=1:1:length(value(:,2))
        %     if value(k,2)>max(vs)      % 频率成分大于s波速度最大值部分的频散能量为p导波频散能量
        %         suo_1(k)=k;      % 输出p导波成分索引
        %     end
        % end
        % suo_1(suo_1==0)=[];
        % value(suo_1,:)=[];      % 清除p导波
        for m=1:1:length(value(:,2))      % 对频率异常值清除
            if value(m,1)>f_max||value(m,1)<f_min
                suo_2(m)=m;
            end
        end
        suo_2(suo_2==0)=[];
        value(suo_2,:)=[];      % 对频率异常值清除
        if ~isempty(value)
            POL=POL+1;      % 索引+1
            varName_n=sprintf('rowx1_%d', POL);      % 创建变量名
            eval([varName_n '=value(:,1:2)']);      % 创建并赋值坐标
        end
    end
end
% 至此已选取所有的x分量频散能量点
%% 对z分量进行处理
dataz=imresize(Z,1);      % 默认不放大
[h,w]=size(dataz);
ave_z=mean(Z(:));
% 区分频散能量与背景噪声
% 输出频散能量点坐标与振幅
coordinatez=[];% 初始化存储坐标矩阵
for i=1:1:h
    for j=1:1:w
        if  dataz(i,j)>Threshold_z*ave_z
            coordinatez=[coordinatez;j+f_min,i+v_min,dataz(i,j);];
        end
    end
end
coordinatez(all(coordinatez==0,2),:)=[];      % 删除矩阵中的0元素
coordinate_2=coordinatez(:,1:2);      % 取坐标列作为DBSCAN的输入数据
%读取两个关键参数的取值
IDX_z=DBSCAN(coordinate_2,epsilon_z,MinPts_z);         % 传入参数运行函数DBSCAN
figure(2)
PlotClusterinResult(coordinate_2, IDX_z, f_min, f_max, v_min, v_max);          % 传入参数，绘制图像
xlabel('频率(Hz)','FontSize',15);
ylabel('相速度(m/s)','FontSize',15);
title(['Z DBSCAN Clustering result(\epsilon = ' num2str(epsilon_z) ', MinPts = ' num2str(MinPts_z) ')']);
% 将DBSCAN聚类结果的每一类分开，将坐标数值索引存放在元胞数组IDX_1中
for i=1:1:length(IDX_z)      % 循环中产生多余0元素
    for j=1:1:max(IDX_z)
        if IDX_z(i)==j
            IDX_2{j}(i)=i;
        end
    end
end
for i=1:1:max(IDX_z)
    IDX_2{1,i}(IDX_2{1,i}==0)=[];  % 删除元胞数组中所有的0元素
end
% 对DBSCAN遗漏的噪声进一步去除
DBSCAN_length=zeros(1,max(IDX_z));      % 比较每一类的频散能量点个数
for i=1:1:max(IDX_z)
    DBSCAN_length(i)=length(IDX_2{1,i});
end
DBSCAN_lct=zeros(1,max(IDX_z));
% 去噪阈值参数
Threshold_2=0.05;% （[0.01,0.05]，对DBSCAN遗漏的噪声进行去除）
for i=1:1:length(DBSCAN_length)      % 设置频散能量投影点个数阈值消除噪声
    if DBSCAN_length(i)>=Threshold_2*mean(DBSCAN_length(:))
        DBSCAN_lct(i)=(i);
    end
    DBSCAN_lct(DBSCAN_lct==0)=[];
end
% 补零并合并频散能量点坐标序号
for i=1:1:max(IDX_z)
    IDX_2{1,i}=[IDX_2{1,i},zeros(1,max(DBSCAN_length)-length(IDX_2{1,i}))];
end
e_location=[];      % 初始化矩阵
for i=1:1:length(DBSCAN_lct)
    e_location=[e_location;IDX_2{1,DBSCAN_lct(i)}];    % 得到有效坐标索引矩阵
end
% 为保证采样点不重复，对每一类的每一频率值取最大频散能量坐标
for i=1:1:size(e_location,1)
    e=e_location(i,:);
    e=e(e~=0);
    x1=coordinatez(e,1);y1=coordinatez(e,2);z1=coordinatez(e,3);
    data_shunxu=sortrows([x1,y1,z1],1);      % 将数据按x坐标的大小顺序排列
    x=data_shunxu(:,1);y=data_shunxu(:,2);z=data_shunxu(:,3);
    unique_x=unique(x);       % 取x所有的唯一值
    for j=1:length(unique_x)
        idx=(x==unique_x(j));      % 获取当前x值的索引
        [max_z(j),idz(j)]=max(z(idx));      % 获取当前x值对应的最大z值
        if j>=2&&j<=length(unique_x)
            idz(j)=length(x(x<=unique_x(j-1)))+idz(j);    % 获取z值在原矩阵中的索引
        end
    end
%     [row,~]=find(z==max_z_for_x);%% 有误
    varName=sprintf('rowz_%d', i);      % 创建变量名
    eval([varName '=data_shunxu(idz(1:length(unique_x)),1:2)']);      % 创建并赋值坐标
%     % 得到最终的坐标索引矩阵
end
VOL=0;      % 初始化索引
for i=1:1:size(e_location,1)
    varName_1=sprintf('rowz_%d', i);      % 读取数据
    value=eval(varName_1);
    if max(value(:,1))-min(value(:,1))>=13&&length(value(:,1))>=10      % 频率范围大于13的认定为频散曲线
        suo=[];    % 异常值索引变量
        suo_1=[];      % p导波索引变量
        suo_2=[];
        for j=2:1:length(value(:,2))-1      % 对除去两端的所有点进行遍历
            if abs(value(j-1,2)+value(j+1,2)-2*value(j,2))>=100    % 根据斜率差绝对值值剔除异常跳动的噪声值
                suo(j)=j;     % 输出异常值索引
            end
        end
        suo(suo==0)=[];
        value(suo,:)=[];      % 对异常值清零
        % for k=1:1:length(value(:,2))
        %     if value(k,2)>max(vs)      % 频率成分大于s波速度最大值部分的频散能量为p导波频散能量
        %         suo_1(k)=k;      % 输出p导波成分索引
        %     end
        % end
        % suo_1(suo_1==0)=[];
        % value(suo_1,:)=[];      % 清除p导波
        for m=1:1:length(value(:,2))      % 对频率异常值清除
            if value(m,1)>f_max||value(m,1)<f_min
                suo_2(m)=m;
            end
        end
        suo_2(suo_2==0)=[];
        value(suo_2,:)=[];      % 对频率异常值清除
        if ~isempty(value)
            VOL=VOL+1;      % 索引+1
            varName_n=sprintf('rowz1_%d', VOL);      % 创建变量名
            eval([varName_n '=value(:,1:2)']);      % 创建并赋值坐标
        end
    end
end
% 至此已选取所有的z分量频散能量点
%% 对x分量频散曲线进行基阶与高阶识别排序
pf_pp=zeros(POL,2);
for i=1:1:POL
    varName_p=sprintf('rowx1_%d', i);      % 读取数据
    value=eval(varName_p);
    pf_pp(i,1)=i;
    pf_pp(i,2)=value(1,1);
end
pf_sortx=sortrows(pf_pp,2);    % 按频率最小值进行排序
% pf_sortx=pf_pp;
pinsan_suo=0;
for i=1:1:POL
    j=pf_sortx(i,1);
    varName_pn=sprintf('rowx1_%d', j);      % 读取数据
    value=eval(varName_pn);
    pinsan_suo=pinsan_suo+1;
    varName_npp=sprintf('PINSANx_%d', pinsan_suo);      % 创建变量名
    eval([varName_npp '=value(:,1:2)']);    % 赋值
end
%% 对z分量频散曲线进行基阶与高阶识别排序
pf_ppz=zeros(VOL,2);
for i=1:1:VOL
    varName_pz=sprintf('rowz1_%d', i);      % 读取数据
    value=eval(varName_pz);
    pf_ppz(i,1)=i;
    pf_ppz(i,2)=value(1,1);
end
pf_sort=sortrows(pf_ppz,2);    % 按频率最小值进行排序
pinsan_suoz=0;
for i=1:1:VOL
    j=pf_sort(i,1);
    varName_pnz=sprintf('rowz1_%d', j);      % 读取数据
    value=eval(varName_pnz);
    pinsan_suoz=pinsan_suoz+1;
    varName_nppz=sprintf('PINSANz_%d', pinsan_suoz);      % 创建变量名
    eval([varName_nppz '=value(:,1:2)']);    % 赋值
end
%% 对x与z分量的频散能量点进行处理
PVL=min(POL,VOL);
PML=max(POL,VOL);
for i=1:1:PVL
    varName_x=sprintf('PINSANx_%d', i);      % 读取去噪后的有效数据
    varName_z=sprintf('PINSANz_%d', i);      % 读取去噪后的有效数据
    pin_x=eval(varName_x);
    pin_z=eval(varName_z);
    pin=[pin_x;pin_z];
    X_pin=pin(:,1);
    Y_pin=pin(:,2);
    pin_shunxu=sortrows([X_pin,Y_pin],1);     % 按频率值从小到大进行排列
    pin_X=pin_shunxu(:,1);pin_Y=pin_shunxu(:,2);
    unique_pinx=unique(pin_X);     % 取pinx的所有唯一值
    pinsan=[];
    for j=1:length(unique_pinx)
        idpinx=(pin_X==unique_pinx(j));      % 获取当前pinx值的索引
        if length(pin_Y(idpinx))>=2
            % 取均值处理
            pin_y_Y=pin_Y(idpinx);
            pinsan=[pinsan;unique(pin_X(idpinx)),(0.8*pin_y_Y(1)+0.2*pin_y_Y(2));];
        else
            pinsan=[pinsan;unique(pin_X(idpinx)),pin_Y(idpinx);];
        end
    end
    varName_f=sprintf('pinsan_%d', i);      % 创建变量名
    eval([varName_f '=pinsan(:,1:2)']);      % 创建并赋值坐标
end
if POL>VOL
    for i=VOL+1:1:POL
        varName_x_1=sprintf('PINSANx_%d', i);
        value=eval(varName_x_1);
        varName_x_2=sprintf('pinsan_%d', i);      % 创建变量名
        eval([varName_x_2 '=value(:,1:2)']);
    end
end
if VOL>POL
    for i=POL+1:1:VOL
        varName_z_1=sprintf('PINSANz_%d', i);
        value=eval(varName_z_1);
        varName_z_2=sprintf('pinsan_%d', i);      % 创建变量名
        eval([varName_z_2 '=value(:,1:2)']);
    end
end
%% 去异常值
for i=1:1:PML
    varName_z_n=sprintf('pinsan_%d', i);
    value=eval(varName_z_n);
    suo=[];
    for j=2:1:length(value(:,2))-1      % 对除去两端的所有点进行遍历
        if abs(value(j-1,2)+value(j+1,2)-2*value(j,2))>=60    % 根据斜率差绝对值值剔除异常跳动的噪声值
            suo(j)=j;     % 输出异常值索引
        end
    end
    suo(suo==0)=[];
    value(suo,:)=[];      % 对异常值清零
    varName_z_n2=sprintf('Pinsan_%d', i);      % 创建变量名
    eval([varName_z_n2 '=value(:,1:2)']);
end
%% 识别的多分量频散曲线与理论正演值对比
for i=1:1:POL
    varName_x=sprintf('PINSANx_%d', i);      % 读取所有频散曲线数据
    value=eval(varName_x);
    figure(3)
    scatter(value(:,1),value(:,2),12,'filled')
    hold on;
    xlim([f_min,f_max]);
    ylim([v_min,v_max]);
    grid on;
    xlabel('频率(Hz)','FontSize',15);
    ylabel('相速度(m/s)','FontSize',15);
%     title('自动拾取的x分量频散曲线')
end
for i=1:1:VOL
    varName_z=sprintf('PINSANz_%d', i);      % 读取所有频散曲线数据
    value=eval(varName_z);
    figure(4)
    scatter(value(:,1),value(:,2),12,'filled')
    hold on;
    xlim([f_min,f_max]);
    ylim([v_min,v_max]);
    grid on;
    xlabel('频率(Hz)','FontSize',15);
    ylabel('相速度(m/s)','FontSize',15);
%     title('自动拾取的z分量频散曲线')
end
% % 地层模型参数设置
% vs=parameter(1,:);    % 横波速度
% vp=parameter(2,:);    % 纵波速度
% den=parameter(3,:);    % 密度
% h=parameter(4,1:length(parameter(1,:))-1);    % 地层厚度
% fr=[f_min:f_max];     % 频率范围
for i=1:1:PML
    varName_2=sprintf('Pinsan_%d', i);      % 读取所有频散曲线数据
    value=eval(varName_2);
%     [frback,vrback]=disper(vs,vp,den,h,fr,i) ;% disper函数输出正演频散曲线频率frback与速度vrback
    figure(5)
    scatter(value(:,1),value(:,2),12,'filled')
    hold on;
%     plot(frback,vrback,'*')
%     hold on;
    xlim([f_min,f_max]);
    ylim([v_min,v_max]);
    grid on;
    xlabel('频率(Hz)','FontSize',15);
    ylabel('相速度(m/s)','FontSize',15);
%     title('自动拾取的频散曲线')
end
figure(11)
imagesc([f_min,f_max],[v_min,v_max],S);
hold on;
for i=1:1:PML
    varName_4=sprintf('Pinsan_%d', i);      % 读取去噪后的有效数据
    value=eval(varName_4);
%     plot(value(:,1),value(:,2),'-wo','linewidth',1.5,'markersize',2.5);
    scatter(value(:,1),value(:,2),12,'w','filled');
    hold on;
%     title('自动拾取的频散曲线','FontSize',15)
end
    set(gca,'Ydir','normal');
    xlabel('频率(Hz)','FontSize',15);
    ylabel('相速度(m/s)','FontSize',15);
    h=colorbar;
    xlim([f_min,f_max]);
    ylim([v_min,v_max]);
    grid on;

figure(12)
clims = [min(S(:)), max(S(:))]
imagesc([f_min,f_max],[v_min,v_max],imresize(S,100),clims);
hold on;
for i=1:1:PML
    varName_4=sprintf('Pinsan_%d', i);      % 读取去噪后的有效数据
    value=eval(varName_4);
    value=smooth_curve(value,0.4);
    scatter(value(:,1),value(:,2),16,'w','filled');
    hold on;
    plot(value(:,1),value(:,2),'w','LineWidth',2)
    hold on;
%     title('自动拾取的频散曲线','FontSize',15)
end
set(gca,'Ydir','normal');
xlabel('Frequency (Hz)');
ylabel('Phase velocity (m/s)');
h=colorbar;
xticklabels({'10', '20', '30', '40', '50'});   % 显示自定义标签
yticklabels({'100','200','300','400','500'});
% colormap jet
set(gca, 'Position', get(gca, 'Position'));  % 保持原位置
set(gcf, 'Position', get(gcf, 'Position') + [0, 0, 75, 0]);  % 调整图窗大小 (可根据需要调整)